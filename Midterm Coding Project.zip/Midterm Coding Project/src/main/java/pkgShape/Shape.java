package pkgShape;

public abstract class Shape {

	public Shape() {
		// TODO Auto-generated constructor stub
	}
	
	public abstract double area();
	public abstract double perimeter();
	
}
